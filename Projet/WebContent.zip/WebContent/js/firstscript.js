function snifferHref() {

	// var element=document.getElementById("link");

	// alert(element.getAttribute("href"));

	var mylink = document.getElementById("link");

	var myButton = document.getElementsByID("myButton");

	myButton.addEventListener("Click", function(event) {
		alert(element.getAttribute("href"));
	});
}